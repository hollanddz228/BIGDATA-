#!/usr/bin/env python3
"""Екі нақты сервердегі қорытынды деректердің толық сәйкестігін тексеру."""
import hashlib
import json
import warnings
from datetime import datetime, timezone, timedelta
from pathlib import Path
from pymongo import MongoClient
from cassandra.cluster import Cluster, ExecutionProfile, EXEC_PROFILE_DEFAULT
from cassandra.policies import DCAwareRoundRobinPolicy

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "results"


def main():
    original = json.loads((ROOT / "data/patients.json").read_text(encoding="utf-8"))
    expected = [dict(p) for p in original if p["id"] != 768]
    expected[1]["room"] = 215
    client = MongoClient("mongodb://127.0.0.1:27017/", serverSelectionTimeoutMS=10000)
    profile = ExecutionProfile(load_balancing_policy=DCAwareRoundRobinPolicy(local_dc="datacenter1"))
    cluster = Cluster(["127.0.0.1"], port=9042, protocol_version=4,
                      execution_profiles={EXEC_PROFILE_DEFAULT: profile})
    try:
        session = cluster.connect("hospital_lab7")
        mongo = list(client.hospital_lab7.patients.find({}, {"_id": 0}).sort("id", 1))
        cassandra = sorted([dict(row._asdict()) for row in session.execute("SELECT id, name, age, diagnosis, room FROM patients")], key=lambda p: p["id"])
        checks = {}
        def check(name, condition):
            checks[name] = "PASS" if condition else "FAIL"
            assert condition, name
        check("source_has_768_records", len(original) == 768)
        check("mongo_final_767", len(mongo) == 767)
        check("cassandra_final_767", len(cassandra) == 767)
        check("mongo_equals_expected_full_dataset", mongo == expected)
        check("cassandra_equals_expected_full_dataset", cassandra == expected)
        check("both_databases_equal_all_fields", mongo == cassandra)
        check("unique_ids", len({p["id"] for p in mongo}) == 767)
        check("deleted_id_absent_both", not any(p["id"] == 768 for p in mongo + cassandra))
        check("room_updated_both", mongo[1]["room"] == cassandra[1]["room"] == 215)
        check("source_age_and_diagnosis_preserved", all(p["age"] == original[p["id"]-1]["age"] and p["diagnosis"] == original[p["id"]-1]["diagnosis"] for p in mongo))
        filtered = list(client.hospital_lab7.patients.find({"age": {"$gt": 40}}, {"_id": 0}).sort([("age", -1), ("id", 1)]))
        expected_filtered = sorted([p for p in expected if p["age"] > 40], key=lambda p: (-p["age"], p["id"]))
        check("mongo_filter_and_sort_complete", filtered == expected_filtered and len(filtered) > 0)
        one = list(session.execute("SELECT id FROM patients WHERE id = 1"))
        several = list(session.execute("SELECT id FROM patients WHERE id IN (1, 2, 3)"))
        check("cassandra_id_equality_one_row", [p.id for p in one] == [1])
        check("cassandra_id_in_three_rows", {p.id for p in several} == {1,2,3})
        server_version = session.execute("SELECT release_version FROM system.local").one().release_version
        result = {
            "verified_at": datetime.now(timezone(timedelta(hours=5))).isoformat(),
            "timezone": "Asia/Qyzylorda",
            "mongo_version": client.server_info()["version"],
            "cassandra_version": server_version,
            "source_count": len(original), "mongo_final_count": len(mongo), "cassandra_final_count": len(cassandra),
            "age_gt40_count": len(filtered), "age_sorted_top5": filtered[:5],
            "positive_final": sum(p["diagnosis"] == "Диабет: оң нәтиже" for p in mongo),
            "negative_final": sum(p["diagnosis"] == "Диабет: теріс нәтиже" for p in mongo),
            "checks": checks, "passed": len(checks), "failed": 0,
        }
        (OUT / "cassandra_final.json").write_text(json.dumps(cassandra, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        (OUT / "verification.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        (OUT / "verification.log").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print(json.dumps(result, ensure_ascii=False, indent=2))
    finally:
        client.close()
        cluster.shutdown()


if __name__ == "__main__":
    main()
