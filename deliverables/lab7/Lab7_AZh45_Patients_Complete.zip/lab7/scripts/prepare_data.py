#!/usr/bin/env python3
"""Ашық медициналық деректерді №7 нұсқаның бес өрісіне түрлендіру."""
import csv
import hashlib
import io
import json
from collections import Counter
from pathlib import Path
from urllib.request import urlopen

ROOT = Path(__file__).resolve().parents[1]
REVISION = "d20fcb6402ae34e653d4513b00f39257bb37ed7f"
BASE = f"https://raw.githubusercontent.com/jbrownlee/Datasets/{REVISION}/"
EXPECTED_SHA256 = "6bfe5d0f379d17a0e0819b996407e3c09bf80febd4287f2ed212190dfff154af"


def main():
    source_dir = ROOT / "data/source"
    source_dir.mkdir(parents=True, exist_ok=True)
    for filename in ("pima-indians-diabetes.data.csv", "pima-indians-diabetes.names"):
        path = source_dir / filename
        if not path.exists():
            with urlopen(BASE + filename, timeout=60) as response:
                path.write_bytes(response.read())
    raw = (source_dir / "pima-indians-diabetes.data.csv").read_bytes()
    assert hashlib.sha256(raw).hexdigest() == EXPECTED_SHA256, "Дереккөздің SHA-256 мәні сәйкес емес"
    source_rows = list(csv.reader(io.StringIO(raw.decode("utf-8"))))
    assert len(source_rows) == 768
    patients, provenance = [], []
    for i, row in enumerate(source_rows, 1):
        assert len(row) == 9
        age, outcome = int(row[7]), int(row[8])
        assert 21 <= age <= 120 and outcome in (0, 1)
        patients.append({
            "id": i,
            "name": f"Пациент-{i:04d}",
            "age": age,
            "diagnosis": "Диабет: оң нәтиже" if outcome else "Диабет: теріс нәтиже",
            "room": 101 + (i - 1) % 50,
        })
        provenance.append({"id": i, "source_row": i, "source_age": age, "source_outcome": outcome})
    assert len({p["id"] for p in patients}) == 768
    (ROOT / "data/patients.json").write_text(json.dumps(patients, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    for name, rows in (("patients.csv", patients), ("provenance.csv", provenance)):
        with (ROOT / "data" / name).open("w", encoding="utf-8", newline="") as stream:
            writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
            writer.writeheader()
            writer.writerows(rows)
    metadata = {
        "title": "Pima Indians Diabetes Database",
        "original_owner": "National Institute of Diabetes and Digestive and Kidney Diseases (NIDDK)",
        "mirror_repository": "https://github.com/jbrownlee/Datasets",
        "revision": REVISION,
        "data_url": BASE + "pima-indians-diabetes.data.csv",
        "description_url": BASE + "pima-indians-diabetes.names",
        "sha256": EXPECTED_SHA256,
        "rows": len(patients),
        "age_min": min(p["age"] for p in patients),
        "age_max": max(p["age"] for p in patients),
        "age_mean": sum(p["age"] for p in patients) / len(patients),
        "outcome_counts": dict(Counter(p["diagnosis"] for p in patients)),
        "real_fields": ["age", "diagnosis (class 0/1 мәнінен алынған белгі)"],
        "educational_fields": ["id (бастапқы файлдағы жол нөмірі)", "name (шартты код)", "room (101..150, оқу үшін жасалған)"],
        "limitations_kk": "Бұл нақты ауруханаға жатқызу тізілімі емес. Бастапқы жиынтықта 21 жастан асқан Pima тобының әйелдері ғана бар; толық халыққа жалпылауға болмайды. Аты-жөндер мен палаталар дереккөзде жоқ. Диагноз өрісі тек диабетке қатысты бинарлық белгіні береді; теріс нәтиже басқа аурудың жоқ екенін білдірмейді. Өзге медициналық бағандар импортталмайды; олардың нөлдік/жетіспейтін мәндері жас өрісіне көшірілмейді.",
        "citation": "Smith J.W., Everhart J.E., Dickson W.C., Knowler W.C., Johannes R.S. (1988). Using the ADAP learning algorithm to forecast the onset of diabetes mellitus. Proceedings of the Symposium on Computer Applications and Medical Care, 261–265.",
        "license_note": "Айна репозиторийінде осы деректер үшін жеке лицензия көрсетілмеген; CC BY сияқты расталмаған лицензия мәлімделмейді. Дереккөз бен ғылыми сілтеме оқу жұмысында көрсетілді.",
    }
    (ROOT / "data/source_metadata.json").write_text(json.dumps(metadata, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    def quote(value):
        return "'" + value.replace("'", "''") + "'"
    statements = ["-- 768 жазба. Тек hospital_lab7 оқу кеңістігіне арналған.", "USE hospital_lab7;"]
    statements.extend(
        f"INSERT INTO patients (id, name, age, diagnosis, room) VALUES ({p['id']}, {quote(p['name'])}, {p['age']}, {quote(p['diagnosis'])}, {p['room']});"
        for p in patients
    )
    (ROOT / "cassandra/02_insert.cql").write_text("\n".join(statements) + "\n", encoding="utf-8")
    print(json.dumps({"rows": len(patients), "age_range": [metadata["age_min"], metadata["age_max"]], "counts": metadata["outcome_counts"], "sha256": EXPECTED_SHA256}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
