#!/usr/bin/env python3
"""Нақты mongosh/cqlsh командаларын орындап, толық журналдарды сақтау."""
import json
import re
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "results"


def execute(args):
    result = subprocess.run(args, capture_output=True, text=True, encoding="utf-8", timeout=180)
    if result.returncode:
        raise RuntimeError(f"Command failed ({result.returncode}): {args}\n{result.stdout}\n{result.stderr}")
    return result.stdout + result.stderr


def main():
    OUT.mkdir(exist_ok=True)
    execute(["docker", "cp", str(ROOT / "data/patients.json"), "lab7-mongo:/tmp/patients.json"])
    execute(["docker", "cp", str(ROOT / "mongodb/lab7.js"), "lab7-mongo:/tmp/lab7.js"])
    mongo = execute(["docker", "exec", "lab7-mongo", "mongosh", "--quiet", "/tmp/lab7.js"])
    (OUT / "mongodb_full.log").write_text(mongo, encoding="utf-8")
    assert "ALL_MONGODB_CHECKS_PASS" in mongo
    execute(["docker", "cp", "lab7-mongo:/tmp/lab7-results/.", str(OUT)])
    sections = {}
    for match in re.finditer(r"\n=== (M\d+) \| (.*?) ===\n(.*?)(?=\n=== M\d+ \||\Z)", mongo, flags=re.S):
        ident, title, text = match.groups()
        sections[ident] = {"title": title, "text": text.strip()}
    execute(["docker", "cp", str(ROOT / "cassandra/02_insert.cql"), "lab7-cassandra:/tmp/lab7_insert.cql"])
    cassandra_log = []
    def section(ident, title, statements):
        lines = []
        for statement in statements:
            output = execute(["docker", "exec", "lab7-cassandra", "cqlsh", "--no-color", "-e", statement])
            lines.append("cqlsh> " + statement + "\n" + (output.strip() or "[exit_code=0]") + "\n")
        text = "\n".join(lines)
        cassandra_log.append(f"=== {ident} | {title} ===\n{text}")
        sections[ident] = {"title": title, "text": text.strip()}
        print(ident, title, flush=True)
    section("C01", "Keyspace және patients кестесін құру", [
        "CREATE KEYSPACE IF NOT EXISTS hospital_lab7 WITH replication = {'class':'SimpleStrategy','replication_factor':1};",
        "CREATE TABLE IF NOT EXISTS hospital_lab7.patients (id int PRIMARY KEY, name text, age int, diagnosis text, room int);",
        "DESCRIBE TABLE hospital_lab7.patients;",
    ])
    section("C02", "768 жазбаны енгізу", [
        "TRUNCATE hospital_lab7.patients;",
        "SOURCE '/tmp/lab7_insert.cql';",
        "SELECT COUNT(*) FROM hospital_lab7.patients;",
    ])
    section("C03", "Барлық 768 жазбаны шығару", ["PAGING OFF; SELECT * FROM hospital_lab7.patients;"])
    assert "(768 rows)" in sections["C03"]["text"]
    section("C04", "Бірегей ID бойынша іздеу", ["SELECT * FROM hospital_lab7.patients WHERE id = 3;"])
    section("C05", "Сандық room өрісін өзгерту", [
        "SELECT id, room FROM hospital_lab7.patients WHERE id = 2;",
        "UPDATE hospital_lab7.patients SET room = 215 WHERE id = 2;",
        "SELECT id, room FROM hospital_lab7.patients WHERE id = 2;",
    ])
    section("C06", "Бір жазбаны жою", [
        "SELECT * FROM hospital_lab7.patients WHERE id = 768;",
        "DELETE FROM hospital_lab7.patients WHERE id = 768;",
        "SELECT * FROM hospital_lab7.patients WHERE id = 768;",
    ])
    section("C07", "Жалпы санын есептеу", ["SELECT COUNT(*) FROM hospital_lab7.patients;"])
    section("C10", "ID бойынша екі түрлі сұраныс", [
        "SELECT * FROM hospital_lab7.patients WHERE id = 1;",
        "SELECT id, name, age, diagnosis, room FROM hospital_lab7.patients WHERE id IN (1, 2, 3);",
    ])
    section("C11", "Нақты іске қосылған нұсқа", ["SELECT release_version, cluster_name, data_center FROM system.local;"])
    (OUT / "cassandra_full.log").write_text("\n\n".join(cassandra_log) + "\n", encoding="utf-8")
    (OUT / "sections.json").write_text(json.dumps(sections, ensure_ascii=False, indent=2), encoding="utf-8")
    print("MONGOSH_AND_CQLSH_TASKS_COMPLETED")


if __name__ == "__main__":
    main()
