#!/usr/bin/env python3
"""№7 зертханалық жұмыстың қазақ тіліндегі Word есебі."""
import json
from pathlib import Path
from docx import Document
from docx.shared import Cm, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "report"
NAME = "Lab7_Tabidulla_Abylaikhan_AZh45"
BLUE = "173C55"
FIGURE = 0


def main():
    global FIGURE
    meta = json.loads((ROOT / "data/source_metadata.json").read_text(encoding="utf-8"))
    verified = json.loads((ROOT / "results/verification.json").read_text(encoding="utf-8"))
    patients = json.loads((ROOT / "data/patients.json").read_text(encoding="utf-8"))
    doc = Document()
    section = doc.sections[0]
    section.page_width, section.page_height = Cm(21), Cm(29.7)
    section.top_margin, section.bottom_margin = Cm(1.8), Cm(1.8)
    section.left_margin, section.right_margin = Cm(2.2), Cm(1.8)
    section.header_distance, section.footer_distance = Cm(0.8), Cm(0.8)
    section.different_first_page_header_footer = True
    styles = doc.styles
    normal = styles["Normal"]
    normal.font.name = "Times New Roman"
    normal.font.size = Pt(12)
    normal.paragraph_format.line_spacing = 1.12
    normal.paragraph_format.space_after = Pt(6)
    normal.paragraph_format.widow_control = True
    for name, size in (("Title", 23), ("Heading 1", 16), ("Heading 2", 13)):
        styles[name].font.name = "Times New Roman"
        styles[name].font.size = Pt(size)
        styles[name].font.color.rgb = RGBColor.from_string(BLUE)
        styles[name].paragraph_format.space_after = Pt(7)
    styles["Caption"].font.name = "Times New Roman"
    styles["Caption"].font.size = Pt(10)
    styles["Caption"].font.color.rgb = RGBColor.from_string("455B6A")
    styles["Caption"].paragraph_format.space_after = Pt(7)
    for sty in styles:
        if sty.type == 1:
            rpr = sty.element.get_or_add_rPr()
            lang = OxmlElement("w:lang")
            lang.set(qn("w:val"), "kk-KZ")
            rpr.append(lang)
    header = section.header.paragraphs[0]
    header.text = "BIG DATA  •  NoSQL деректер базалары  •  №7  •  АЖ45"
    header.runs[0].font.size = Pt(9)
    header.runs[0].font.color.rgb = RGBColor.from_string("566D7E")
    footer = section.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    footer.add_run("Табидулла Абылайхан  |  ").font.size = Pt(9)
    fld = OxmlElement("w:fldSimple")
    fld.set(qn("w:instr"), "PAGE")
    footer._p.append(fld)
    doc.core_properties.title = "Зертханалық жұмыс №7. NoSQL деректер базалары: MongoDB және Cassandra"
    doc.core_properties.subject = "№7 нұсқа — Аурухана / patients"
    doc.core_properties.author = "Табидулла Абылайхан"
    doc.core_properties.keywords = "АЖ45, BigDATA, MongoDB, Cassandra, patients, 768"

    def p(text="", bold=False, size=None):
        paragraph = doc.add_paragraph()
        paragraph.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
        run = paragraph.add_run(text)
        run.bold = bold
        if size:
            run.font.size = Pt(size)
        return paragraph

    def h(text, level=1):
        return doc.add_heading(text, level=level)

    def page(title):
        heading = h(title)
        heading.paragraph_format.page_break_before = True

    def table(headers, rows, widths=None, size=10):
        t = doc.add_table(rows=1, cols=len(headers))
        t.style = "Table Grid"
        t.autofit = False
        for cell, title in zip(t.rows[0].cells, headers):
            cell.text = str(title)
            shd = OxmlElement("w:shd")
            shd.set(qn("w:fill"), "E6EEF3")
            cell._tc.get_or_add_tcPr().append(shd)
        for values in rows:
            for cell, value in zip(t.add_row().cells, values):
                cell.text = str(value)
        for rindex, row in enumerate(t.rows):
            trpr = row._tr.get_or_add_trPr()
            no_split = OxmlElement("w:cantSplit")
            trpr.append(no_split)
            if rindex == 0:
                repeat = OxmlElement("w:tblHeader")
                trpr.append(repeat)
            for cindex, cell in enumerate(row.cells):
                if widths:
                    cell.width = Cm(widths[cindex])
                for para in cell.paragraphs:
                    para.paragraph_format.space_after = Pt(3)
                    para.paragraph_format.space_before = Pt(3)
                    para.paragraph_format.line_spacing = 1
                    for run in para.runs:
                        run.font.size = Pt(size)
                        run.bold = rindex == 0
        p()
        return t

    def code(text):
        para = doc.add_paragraph()
        para.paragraph_format.space_before = Pt(3)
        para.paragraph_format.space_after = Pt(7)
        para.paragraph_format.line_spacing = 1.0
        run = para.add_run(text)
        run.font.name = "DejaVu Sans Mono"
        run.font.size = Pt(9)
        shd = OxmlElement("w:shd")
        shd.set(qn("w:fill"), "F1F4F6")
        para._p.get_or_add_pPr().append(shd)
        return para

    def figure(ident, caption, max_height=11.5):
        nonlocal doc
        global FIGURE
        file = ROOT / "screenshots" / f"{ident}.png"
        width, height = Image.open(file).size
        width_cm = min(17.0, max_height * width / height)
        para = doc.add_paragraph()
        para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        para.paragraph_format.space_after = Pt(3)
        para.paragraph_format.keep_with_next = True
        para.add_run().add_picture(str(file), width=Cm(width_cm))
        FIGURE += 1
        cp = doc.add_paragraph(f"{FIGURE}-сурет. {caption} ({ident}).", style="Caption")
        cp.alignment = WD_ALIGN_PARAGRAPH.CENTER

    # 1. Титулдық бет.
    for _ in range(2):
        p()
    t = doc.add_paragraph("ҮЛКЕН ДЕРЕКТЕРДІ ӨҢДЕУ\n(BigDATA)")
    t.alignment = WD_ALIGN_PARAGRAPH.CENTER
    for r in t.runs:
        r.bold, r.font.size = True, Pt(16)
    p()
    t = doc.add_paragraph("ЗЕРТХАНАЛЫҚ ЖҰМЫС №7", style="Title")
    t.alignment = WD_ALIGN_PARAGRAPH.CENTER
    t = doc.add_paragraph("NoSQL деректер базалары:\nMongoDB және Cassandra")
    t.alignment = WD_ALIGN_PARAGRAPH.CENTER
    t.runs[0].font.size = Pt(18)
    p()
    t = doc.add_paragraph("№7 нұсқа — Аурухана\npatients: id, name, age, diagnosis, room")
    t.alignment = WD_ALIGN_PARAGRAPH.CENTER
    t.runs[0].font.size = Pt(14)
    p()
    p("Орындаған: Табидулла Абылайхан", bold=True, size=14)
    p("Тобы: АЖ45", bold=True, size=14)
    p()
    p("Деректер көлемі: 768 медициналық жазба\nОрындалған орта: MongoDB 7.0.16 және Apache Cassandra 4.1.7")
    p()
    t = doc.add_paragraph("2026 жыл")
    t.alignment = WD_ALIGN_PARAGRAPH.CENTER

    # 2. Мақсат және бағалау талаптары.
    page("1. Жұмыстың мақсаты және орындалу талаптары")
    p("Мақсат — MongoDB және Cassandra NoSQL жүйелерінде деректер құрылымын құру, пациенттер туралы ақпаратты енгізу, оқу, жаңарту және жою операцияларын меңгеру; екі жүйенің сұраныс жасау ерекшеліктерін салыстыру [1, 2].")
    h("Қысқаша теория", 2)
    p("MongoDB — құжатқа бағытталған жүйе: деректер BSON құжаттары ретінде коллекцияда сақталады. Cassandra — кең бағанды, таратылған жүйе: кестелер keyspace ішінде орналасады, ал partition key деректердің бөлімдерге бөлінуін анықтайды. CRUD: Create — қосу; Read — оқу; Update — өзгерту; Delete — жою.")
    p("№7 нұсқаның тақырыбы — «Аурухана», коллекция/кесте — patients. Бастапқы тапсырма кемінде 10 жазбаны талап етеді; қосымша талапқа сәйкес 768 жазба пайдаланылды. 8–9-тармақ MongoDB-де, 10-тармақ Cassandra-да орындалады [1].")
    table(["№", "Тапсырма", "Орындалуы"], [
        (1, "Деректер базасын және коллекция/кесте құру", "MongoDB + Cassandra"),
        (2, "Жазбаларды енгізу", "Әр жүйеге 768 жазба"),
        (3, "Барлық жазбаларды шығару", "768 жол; толық журналдар"),
        (4, "Бірегей ID арқылы іздеу", "Екі жүйеде id=3"),
        (5, "Сандық өрісті өзгерту", "id=2: room 102 → 215"),
        (6, "Бір жазбаны жою", "Екі жүйеде id=768"),
        (7, "Жалпы санын есептеу", "Әр жүйеде 767"),
        (8, "Сандық өріс бойынша салыстыру", "MongoDB: age > 40"),
        (9, "Сандық өріс бойынша сұрыптау", "MongoDB: age кему реті"),
        (10, "ID бойынша екі түрлі сұраныс", "Cassandra: = және IN"),
    ], [0.7, 9.2, 7.1], 10.5)
    p("Қосымша тапсырма: MongoDB-де жасы 40-тан жоғары пациенттерді тауып, жасын кему ретімен сұрыптау. Сұраныс №7 нұсқасына бейімделді: patients коллекциясының age өрісі қолданылды.", size=10.5)

    # 3. Дереккөз.
    page("2. Нақты дереккөз және деректерді дайындау")
    p("Pima Indians Diabetes Database жиынтығындағы 768 бақылау алынды. Бастапқы иесі — АҚШ-тың National Institute of Diabetes and Digestive and Kidney Diseases (NIDDK) мекемесі. Жиынтықта Pima тобына жататын, жасы кемінде 21-ге толған әйелдердің медициналық көрсеткіштері бар [3, 4].")
    p("Файл ашық GitHub айнасынан жүктелді. Қайта өндіру үшін master тармағының жылжымалы сілтемесі емес, нақты commit нұсқасы бекітілді. Түпнұсқа сипаттамасы мен CSV файлдары бірге сақталды.")
    table(["Көрсеткіш", "Мәні"], [
        ("Бастапқы жол саны", 768), ("Жас аралығы", "21–81 жас"),
        ("Орташа жас", f"{meta['age_mean']:.2f} жас".replace(".", ",")),
        ("Диабет белгісі оң / теріс", "268 / 500"),
        ("Бастапқы CSV", "Тақырып жолынсыз: 8 белгі және 1 class бағаны"),
    ], [6.0, 11.0], 11)
    h("Бес өріске сәйкестендіру", 2)
    table(["Өріс", "Типі", "Шығу тегі мен мағынасы"], [
        ("id", "int", "Бастапқы CSV жол нөмірі: 1–768; оқу идентификаторы."),
        ("name", "string / text", "Пациент-0001 түріндегі шартты код; нақты аты-жөн емес."),
        ("age", "int", "Бастапқы 8-баған; толық жылмен берілген жас."),
        ("diagnosis", "string / text", "9-баған: 1 → «Диабет: оң нәтиже», 0 → «Диабет: теріс нәтиже»."),
        ("room", "int", "101 + (id−1) mod 50; 101–150 аралығындағы оқу палатасы."),
    ], [2.0, 3.3, 11.7], 10.5)
    p("Маңызды шектеу: бұл — нақты ауруханаға жатқызу тізілімі емес. Дереккөзде аты-жөндер мен палата нөмірлері жоқ; олар оқу моделін толықтыру үшін ғана берілді. Теріс диабет белгісі басқа аурулардың жоқтығын білдірмейді. Жиынтық бүкіл халықты сипаттамайды.", bold=True, size=10.5)

    # 4. Деректер үлгісі және іске қосу.
    page("3. Бастапқы деректер үлгісі және жұмыс ортасы")
    p("Төменде бастапқы импорт файлындағы алғашқы 10 жазба берілген. Кестеде diagnosis өрісіндегі «Диабет: оң нәтиже» және «Диабет: теріс нәтиже» мәтіндері ықшамдалып көрсетілді.")
    table(["id", "name", "age", "diagnosis", "room"], [
        (r["id"], r["name"], r["age"], "оң нәтиже" if "оң" in r["diagnosis"] else "теріс нәтиже", r["room"])
        for r in patients[:10]
    ], [1.0, 5.0, 1.5, 6.5, 3.0], 10.5)
    h("Құралдар мен орта", 2)
    table(["Компонент", "Нақты қолданылған нұсқа / баптау"], [
        ("MongoDB Community", "7.0.16; mongo:7.0.16 контейнері"),
        ("MongoDB Shell", "mongosh 2.3.8"),
        ("Apache Cassandra", "4.1.7; cassandra:4.1.7 контейнері"),
        ("CQL Shell", "cqlsh 6.1.0"),
        ("Cassandra кластері", "Lab7Hospital; 1 түйін; datacenter1; RF=1"),
        ("Орындау және тексеру", "Python 3.12; pymongo 4.10.1; cassandra-driver 3.29.2"),
    ], [5.4, 11.6], 10.5)
    p("Екі сервер іске қосылып, MongoDB ping және Cassandra system.local сұраныстарымен тексерілді. Cassandra heap көлемі — 1 GiB. Қызметтер localhost порттарында жұмыс істейді: 27017 және 9042.")
    code("cd /workspace/BIGDATA-/lab7\nbash scripts/start_services.sh\npython scripts/prepare_data.py\npython scripts/run_tasks.py")
    p("Есептегі скриншоттар нақты mongosh/cqlsh командалары мен шығыс журналдарының HTML көрінісін Chromium-да түсіру арқылы алынды. Үлкен тізімдердің қысқартылған жерлері белгіленген; толық нәтижелер results/ каталогында сақталған.", size=10.5)

    # 5. Mongo schema+insert.
    page("4. MongoDB: база құру және деректер енгізу")
    p("1-тапсырма. hospital_lab7 деректер базасы және patients коллекциясы құрылды. JSON Schema бес міндетті өрісті тексереді. id үшін бірегей индекс қойылды; MongoDB-дің автоматты _id өрісі сақталады.")
    figure("M01", "База, коллекция схемасы және бірегей id индексі", 10)
    p("2-тапсырма. patients.json файлындағы 768 жазба insertMany() арқылы енгізілді. Сандық өрістер NumberInt түріне келтірілді. acknowledged=true және insertedCount=768 нәтижелері импорттың орындалғанын көрсетеді.")
    figure("M02", "768 құжатты енгізу және бастапқы санын тексеру", 7)

    # 6. Mongo read.
    page("5. MongoDB: барлық жазбаны оқу және ID арқылы іздеу")
    p("3-тапсырма. find() арқылы барлық 768 құжат оқылды. sort({id:1}) нәтижені түсінікті ретпен береді. forEach() барлық құжатты журналға шығарады; интерактивті shell-дегі алғашқы бетпен шектелмейді.")
    figure("M03", "Барлық құжаттарды шығару журналының белгіленген үзіндісі", 10)
    p("Толық 768 жол results/mongodb_full.log және results/mongo_all_before.json файлдарында сақталған. Скриншотта тек оқуға ыңғайлы үзінді көрсетілген.", size=10.5)
    p("4-тапсырма. Бірегей id=3 бойынша пациент табылды: жасы 32, диабет белгісі оң, палата 103. _id:0 проекциясы есепте тек нұсқадағы бес өрісті көрсетеді.")
    figure("M04", "id=3 бойынша бір құжатты іздеу", 6)

    # 7. Mongo update delete.
    page("6. MongoDB: өзгерту, жою және санау")
    p("5-тапсырма. id=2 пациентінің сандық room өрісі 102-ден 215-ке өзгертілді. Жас пен медициналық белгі бастапқы күйінде қалды. matchedCount=1 және modifiedCount=1 — бір құжат жаңартылғанының дәлелі.")
    figure("M05", "room өрісінің өзгеріске дейінгі және кейінгі мәндері", 7.5)
    p("6-тапсырма. id=768 жазбасы жойылды. deletedCount=1; қайта іздегендегі null нәтижесі жазбаның жоқ екенін көрсетеді.")
    figure("M06", "Бір құжатты жою және қайта іздеу", 6.5)
    p("7-тапсырма. Қорытынды саны: 768 − 1 = 767. Бұл көлем 500 жазбалық қосымша талаптан жоғары.")
    figure("M07", "Жоюдан кейінгі жалпы құжат саны", 4)

    # 8. Mongo compare sort.
    page("7. MongoDB: сандық салыстыру және сұрыптау")
    p("8-тапсырма. age > 40 шарты $gt операторы арқылы орындалды. 40 жастың өзі шартқа кірмейді. Нәтиже — 194 пациент; төменде алғашқы бес жазба көрсетілген. Толық сүзгі нәтижесі mongo_age_gt40.json файлында.")
    figure("M08", "Жасы 40-тан жоғары пациенттерді табу", 9)
    p("9-тапсырма. age:-1 — жасты кему ретімен сұрыптау. Жасы бірдей болса id:1 екінші сұрыптау шарты тұрақты ретті қамтамасыз етеді. limit(5) тек есептегі көріністі шектейді; барлық 767 сұрыпталған жазба бөлек JSON файлында сақталған.")
    figure("M09", "Жас бойынша кему ретімен сұрыптау", 9)

    # 9. Additional.
    page("8. MongoDB: нұсқаға арналған қосымша сұраныс")
    p("Қосымша тапсырмада салыстыру мен сұрыптау бір сұранысқа біріктірілді. Таңдалған шек — 40 жас: бұл мән бастапқы деректегі 21–81 жас аралығында орналасқан және бос емес нәтиже береді.")
    code("db.patients.find({age: {$gt: 40}}, {_id: 0})\n  .sort({age: -1, id: 1})")
    figure("M10", "age > 40 шарты және жас бойынша кему реті", 10)
    table(["Реті", "id", "Пациент коды", "Жасы", "Палата"], [
        (i, r["id"], r["name"], r["age"], r["room"])
        for i, r in enumerate(verified["age_sorted_top5"], 1)
    ], [1.2, 1.5, 7.0, 3.0, 4.3], 11)
    p("Толық 194 жазба results/mongo_filtered_sorted.json файлында. 81, 72, 70, 69, 69 тізбегі кему ретін көрсетеді; жасы 69 болатын екі жазбаның id мәндері 124 және 685 болып өсу ретімен орналасқан.")

    # 10. Cassandra create.
    page("9. Cassandra: keyspace, кесте және импорт")
    p("1-тапсырма. hospital_lab7 keyspace ішінде patients кестесі құрылды. id int PRIMARY KEY бір уақытта partition key болады. Әрбір id жеке бөлімге сәйкес келеді. SimpleStrategy және replication_factor=1 тек бір түйінді оқу ортасына арналған.")
    figure("C01", "Keyspace пен patients кестесін құру және схемасын көру", 10.5)
    p("2-тапсырма. 768 INSERT операторы бар CQL файл SOURCE командасы арқылы орындалды. Алдын ала TRUNCATE тек осы зертхананың оқу кестесін тазартады. COUNT нәтижесі — 768.")
    figure("C02", "CQL файлын орындау және енгізілген жазбаларды санау", 8)

    # 11. Cassandra read.
    page("10. Cassandra: барлық жазбаны оқу және ID іздеу")
    p("3-тапсырма. PAGING OFF командасы барлық нәтижені көрсетуге мүмкіндік береді. SELECT * FROM patients сұранысы 768 жолды қайтарды. Cassandra-да бұл сұраныс нәтижесі id бойынша сұрыпталған деп қабылданбайды.")
    figure("C03", "Барлық 768 жолды шығару нәтижесінің белгіленген үзіндісі", 10)
    p("Нәтиженің толық мәтіні results/cassandra_full.log ішінде. Жолдардың аралас реті қате емес: бөлім кілттері хэш-токендер бойынша таратылады.", size=10.5)
    p("4-тапсырма. WHERE id=3 нақты бөлім кілтін береді; бір жол қайтарылады. Бұл жолдың бес өрісі MongoDB-дегі id=3 құжатымен сәйкес келеді.")
    figure("C04", "id=3 бойынша бір жолды іздеу", 6.5)

    # 12. Cassandra update delete.
    page("11. Cassandra: өзгерту және жою")
    p("5-тапсырма. Алдымен id=2 жолындағы room=102 мәні оқылды. UPDATE patients SET room=215 WHERE id=2; командасынан кейін SELECT room=215 екенін растады. Cassandra-дағы UPDATE upsert семантикасына ие; бұл жұмыста бар id алдын ала тексерілді.")
    figure("C05", "room мәнін 102-ден 215-ке өзгерту", 9)
    p("6-тапсырма. id=768 жолы DELETE арқылы жойылды. Одан кейін сол ID бойынша SELECT сұранысы (0 rows) қайтарды. Cassandra жоюды tombstone арқылы белгілейді; физикалық тазарту кейінгі compaction және GC шарттарына байланысты.")
    figure("C06", "Жолды жою және жоқ екенін тексеру", 10)

    # 13. Cassandra count+queries.
    page("12. Cassandra: санау және екі түрлі ID сұранысы")
    p("7-тапсырма. SELECT COUNT(*) нәтижесі — 767. «Aggregation query used without partition key» ескертуі толық кестені сканерлеу туралы хабарлайды. Бұл қате емес, бірақ үлкен өндірістік кестеде мұндай санау қымбат операция болады.")
    figure("C07", "Жоюдан кейінгі 767 жол және COUNT ескертуі", 6.5)
    p("10-тапсырма. Бірінші сұраныс WHERE id=1 арқылы бір бөлімді оқиды және 1 жол қайтарады. Екінші сұраныс WHERE id IN (1,2,3) арқылы үш ID-ге жүгінеді және 3 жол қайтарады. IN нәтижесі сұралған тізім ретімен келеді деп кепілдік берілмейді.")
    figure("C10", "ID теңдігі және ID жиыны бойынша екі түрлі сұраныс", 10)
    p("age бойынша еркін WHERE немесе жаһандық ORDER BY бұл схемаға қолданылмады. Мұндай сұраныстар үшін нақты сұранысқа бейімделген partition/clustering кілттері бар қосымша кесте қажет; ALLOW FILTERING үлкен көлемде тиімді шешім болып саналмайды.", size=10.5)

    # 14. comparison.
    page("13. MongoDB және Cassandra салыстыру")
    table(["Сипаттама", "MongoDB", "Cassandra"], [
        ("Деректер моделі", "BSON құжаттары және коллекциялар", "Keyspace, кесте, бөлім және жол"),
        ("Осы жұмыстағы құрылым", "hospital_lab7.patients", "hospital_lab7.patients"),
        ("Бірегейлік", "_id және id үшін unique индекс", "id PRIMARY KEY"),
        ("Сұраныс тәсілі", "find, $gt, sort, проекция", "CQL; кілттерге сай сұраныс"),
        ("Жаңарту", "$set тек берілген өрісті өзгертеді", "UPDATE кілтпен жаңартады; upsert"),
        ("Жаспен сүзгілеу", "Осы модельде тікелей орындалды", "Сұранысқа сай бөлек модель қажет"),
        ("Сұрыптау", "age және id бойынша sort", "Бөлім ішіндегі clustering ретімен шектеледі"),
        ("Масштабтау", "Replica set және sharding", "Тең дәрежелі түйіндер, бөлімдерді тарату"),
        ("Келісімділік", "Read/write concern параметрлеріне тәуелді", "Consistency level және RF-ке тәуелді"),
        ("Осы жұмыстағы нәтиже", "768 енгізілді; 767 қалды", "768 енгізілді; 767 қалды"),
    ], [4.0, 6.5, 6.5], 10.5)
    p("MongoDB құжаттармен икемді жұмыс істеуге, әртүрлі өрістер бойынша іздеуге және сұрыптауға қолайлы. Cassandra-да жоғары жазу жүктемесі мен таратылған сақтау үшін сұраныстарға сәйкес деректер моделі алдын ала жобаланады [2, 5, 6].")
    p("Осы жұмыс бір түйінді оқу ортасында орындалды. 768 жазба тапсырманың талабын орындайды, бірақ үлкен деректер масштабындағы өнімділік, шардтау, репликация немесе түйін істен шыққандағы қолжетімділік тәжірибеде өлшенген жоқ. Сондықтан бір жүйе екіншісінен жылдамырақ деген қорытынды жасалмайды.")
    p("RF=1 жағдайында Cassandra-да екінші көшірме жоқ. MongoDB контейнері де replica set емес. Дәрістегі ақауға төзімділік пен көлденең масштабтау артықшылықтары тиісті көп түйінді конфигурацияда іске асады.")

    # 15. actual checks.
    page("14. Нәтижелердің дұрыстығын тексеру")
    p("Нәтижелер тек экрандағы алғашқы жолдармен бағаланған жоқ. Python драйверлері екі нақты серверден барлық қорытынды жазбаларды қайта оқып, оларды бастапқы файлдан есептелген күтілетін күймен салыстырды. id=2 палатасы ғана өзгеріп, id=768 ғана жойылуы тиіс.")
    labels = [
        "Бастапқы файлда 768 жазба бар", "MongoDB-де 767 жазба қалды", "Cassandra-да 767 жазба қалды",
        "MongoDB-дің барлық өрісі күтілетін күймен сәйкес", "Cassandra-ның барлық өрісі күтілетін күймен сәйкес",
        "Екі базаның барлық 767 жазбасы толық сәйкес", "ID мәндері бірегей", "id=768 екі базада да жоқ",
        "id=2 үшін room=215 екі базада да сақталған", "Бастапқы age және diagnosis мәндері сақталған",
        "MongoDB сүзгісі мен сұрыптауы толық дұрыс", "Cassandra id=1 сұранысы бір жол берді",
        "Cassandra IN сұранысы дәл 1, 2, 3 ID-лерін берді",
    ]
    table(["№", "Тексеру", "Нәтиже"], [(i, label, "Өтті") for i, label in enumerate(labels,1)], [0.8, 13.0, 3.2], 10.5)
    p("Барлығы: 13 тексеру өтті, 0 тексеру сәтсіз аяқталды. Нәтижелер results/verification.json және verification.log файлдарында сақталған.", bold=True)
    table(["Қорытынды көрсеткіш", "Мәні"], [
        ("Әр базаға енгізілгені / соңында қалғаны", "768 / 767"),
        ("Соңғы оң / теріс диабет белгісі", "268 / 499"),
        ("Жасы 40-тан жоғары пациенттер", "194"),
        ("Соңғы деректердің сәйкестігі", "767 жол × 5 өріс — толық сәйкес"),
        ("Орындалу уақыты", verified["verified_at"][:19].replace("T", " ") + " (UTC+5)"),
    ], [10.5, 6.5], 10.5)
    p("Дереккөздің SHA-256 мәні жүктеу кезінде тексерілді; 768 жолдың әрқайсысында тоғыз бастапқы баған бар. Жас пен class өрістерінің рұқсат етілген мәндері тексерілді. Енгізу сценарийін қайта орындау бастапқы оқу күйін қалпына келтіріп, сол қорытынды нәтижеге жеткізді.", size=10.5)

    # 16. conclusion.
    page("15. Қорытынды және қоса берілген файлдар")
    p("Зертханалық жұмыста №7 «Аурухана» нұсқасы бойынша patients коллекциясы мен кестесі құрылды. Ашық медициналық дереккөздің 768 жазбасы MongoDB және Cassandra жүйелеріне енгізілді. Екі ортада CRUD операциялары орындалып, бір жазба өзгертілді, бір жазба жойылды және 767 жазба қалғаны тексерілді.")
    p("MongoDB-де age > 40 шартына сәйкес 194 жазба табылып, жас бойынша кему ретімен сұрыпталды. Cassandra-да ID теңдігі мен ID жиыны бойынша сұраныстар орындалды; олардың бөлім кілтімен байланысы түсіндірілді. Екі базаның соңғы деректері барлық бес өріс бойынша толық сәйкес келді.")
    p("Нақты дереккөздегі жас пен диабет белгісі сақталды. Шартты пациент кодтары мен оқу палаталары нақты аты-жөн немесе нақты аурухана деректері ретінде ұсынылмайды. Жұмыс NoSQL жүйелерінің деректерді сақтау және сұраныс жасау ерекшеліктерін тәжірибе жүзінде меңгеруге мүмкіндік берді.")
    table(["Файл / каталог", "Мақсаты"], [
        ("report/*.docx, *.pdf", "Қазақша есеп және басып шығаруға арналған көшірме"),
        ("data/patients.json, patients.csv", "Импортқа дайын 768 жазба"),
        ("data/source/", "Бастапқы CSV және дереккөз сипаттамасы"),
        ("data/provenance.csv", "Бастапқы жол нөмірі мен белгілер сәйкестігі"),
        ("mongodb/lab7.js", "Барлық MongoDB тапсырмалары"),
        ("cassandra/*.cql", "Схема, 768 INSERT және CQL тапсырмалары"),
        ("results/*_full.log", "Барлық жазбаны қамтитын орындалу журналдары"),
        ("results/*_final.json", "Әр базаның соңғы 767 жазбасы"),
        ("results/verification.json", "13 тексерудің толық нәтижесі"),
        ("screenshots/", "Нақты журналдардан алынған PNG көріністері"),
        ("scripts/, README_kk.md", "Қайта орындау және есеп жасау нұсқаулығы"),
    ], [7.5, 9.5], 10.5)
    p("Қайта орындау тәртібі README_kk.md ішінде. Сценарийлер тек hospital_lab7 атты оқу базасына арналған. Деректер томдары сақталады, ал контейнер процестері жаңа ортада қайта іске қосылады.", size=10.5)

    # 17. references.
    page("16. Пайдаланылған дереккөздер")
    refs = [
        "[1] «7_ЗЕРТХАНАЛЫҚ ЖҰМЫС.docx». Пайдаланушы ұсынған зертханалық жұмыс нұсқаулығы: ортақ 10 тапсырма, №7 нұсқа және есеп құрылымы.",
        "[2] «ЛЕКЦИЯ жетінші апта қосымша дәріс.docx». Пайдаланушы ұсынған NoSQL, MongoDB және Cassandra туралы қосымша дәріс.",
        "[3] Pima Indians Diabetes Database. Бастапқы иесі: NIDDK. Донор: Vincent Sigillito. Бастапқы сипаттама: pima-indians-diabetes.names. Айна репозиторийі: https://github.com/jbrownlee/Datasets .",
        "[4] Smith J. W., Everhart J. E., Dickson W. C., Knowler W. C., Johannes R. S. (1988). Using the ADAP learning algorithm to forecast the onset of diabetes mellitus. Proceedings of the Symposium on Computer Applications and Medical Care, 261–265.",
        "[5] MongoDB Manual. CRUD Operations; find, updateOne, deleteOne, countDocuments, sort. https://www.mongodb.com/docs/manual/crud/ .",
        "[6] Apache Cassandra 4.1 Documentation. CQL: Data Manipulation; SELECT, INSERT, UPDATE, DELETE. https://cassandra.apache.org/doc/4.1/cassandra/cql/dml.html .",
    ]
    for ref in refs:
        p(ref, size=11)
    h("Дерек файлын дәл сәйкестендіру", 2)
    p("Алынған күні: 15.10.2026. Бекітілген Git commit:", size=10.5)
    code(meta["revision"])
    p("CSV файлының SHA-256 бақылау қосындысы:", size=10.5)
    code(meta["sha256"])
    p("Нақты CSV сілтемесі:", size=10.5)
    p(meta["data_url"], size=9)
    p("Дереккөздің бастапқы сипаттама сілтемесі:", size=10.5)
    p(meta["description_url"], size=9)
    p("CSV, сипаттама, бекітілген нұсқа және бақылау қосындысы қоса сақталған. Файлдардың лицензиясы туралы расталмаған мәлімет берілмейді; бастапқы иесі мен ғылыми жұмысқа сілтеме көрсетілді.", size=10)
    OUT.mkdir(exist_ok=True)
    target = OUT / f"{NAME}.docx"
    doc.save(target)
    print(target)
    print("Суреттер:", FIGURE)


if __name__ == "__main__":
    main()
