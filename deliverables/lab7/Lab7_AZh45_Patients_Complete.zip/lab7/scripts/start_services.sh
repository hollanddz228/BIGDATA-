#!/usr/bin/env bash
set -euo pipefail
# Қолданыстағы контейнерлерді қайта пайдалану; деректер томдарын жоймау.
if docker container inspect lab7-mongo >/dev/null 2>&1; then
  docker start lab7-mongo >/dev/null
else
  docker run -d --name lab7-mongo -p 127.0.0.1:27017:27017 \
    -v lab7-mongo-data:/data/db mongo:7.0.16 --bind_ip_all
fi
if docker container inspect lab7-cassandra >/dev/null 2>&1; then
  docker start lab7-cassandra >/dev/null
else
  docker run -d --name lab7-cassandra -p 127.0.0.1:9042:9042 \
    -e CASSANDRA_CLUSTER_NAME=Lab7Hospital -e MAX_HEAP_SIZE=1G \
    -e HEAP_NEWSIZE=256M -e CASSANDRA_CONCURRENT_READS=8 \
    -e CASSANDRA_CONCURRENT_WRITES=8 \
    -v lab7-cassandra-data:/var/lib/cassandra cassandra:4.1.7
fi
for n in $(seq 1 60); do
  if docker exec lab7-mongo mongosh --quiet --eval 'quit(db.adminCommand({ping:1}).ok === 1 ? 0 : 1)' >/dev/null 2>&1 && \
     docker exec lab7-cassandra cqlsh -e 'SELECT release_version FROM system.local;' >/dev/null 2>&1; then
    echo 'MongoDB және Cassandra: READY'
    exit 0
  fi
  sleep 3
done
echo 'Іске қосылмады: docker logs lab7-mongo; docker logs lab7-cassandra' >&2
exit 1
