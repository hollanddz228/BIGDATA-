#!/usr/bin/env python3
"""Нақты орындалу журналдарының HTML көрінісін Chromium арқылы түсіру."""
import html
import json
import re
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]


def excerpt(text, head, tail):
    lines = text.splitlines()
    if len(lines) <= head + tail:
        return text
    return "\n".join(lines[:head] + [f"[… {len(lines)-head-tail} жол қысқартылды; толық нәтиже журнал файлында …]"] + (lines[-tail:] if tail else []))


def main():
    sections = json.loads((ROOT / "results/sections.json").read_text(encoding="utf-8"))
    sections["M03"]["text"] = excerpt(sections["M03"]["text"], 6, 2)
    sections["C03"]["text"] = excerpt(sections["C03"]["text"], 9, 5)
    sections["C01"]["text"] = excerpt(sections["C01"]["text"], 14, 0)
    with sync_playwright() as p:
        browser = p.chromium.launch(executable_path="/usr/bin/chromium", headless=True, args=["--no-sandbox"])
        page = browser.new_page(viewport={"width": 1120, "height": 900}, device_scale_factor=1.5)
        for ident, section in sections.items():
            if ident in ("M11",):
                continue
            engine = "MongoDB 7.0.16 · mongosh 2.3.8" if ident.startswith("M") else "Cassandra 4.1.7 · cqlsh 6.1.0"
            lines = []
            for line in section["text"].splitlines():
                cls = "command" if line.startswith(("hospital_lab7>", "mongosh>", "cqlsh>")) else "output"
                if line.startswith("[…"):
                    cls = "notice"
                lines.append(f'<div class="line {cls}">{html.escape(line) or "&nbsp;"}</div>')
            log = "mongodb_full.log" if ident.startswith("M") else "cassandra_full.log"
            body = f'''<!doctype html><html lang="kk"><meta charset="utf-8"><style>
            * {{box-sizing:border-box}} body {{margin:0;background:#fff;color:#142b40;font-family:"DejaVu Sans",sans-serif}}
            .top {{padding:17px 24px;background:#163b55;color:#fff;font-size:20px;font-weight:bold}}
            .sub {{padding:12px 24px;border-bottom:1px solid #d4e0e8;font-size:19px;font-weight:bold}}
            .terminal {{padding:17px 24px;background:#f6f8fa}}
            .line {{white-space:pre-wrap;overflow-wrap:anywhere;font-family:"DejaVu Sans Mono",monospace;font-size:22px;line-height:1.40}}
            .command {{color:#125588;font-weight:bold;margin-top:8px}}
            .notice {{color:#855b18;font-style:italic;font-size:16px}}
            .foot {{padding:12px 24px;font-size:14px;border-top:1px solid #d4e0e8;color:#4f6170}}
            </style><div class="top">{html.escape(engine)} · №7 Аурухана</div>
            <div class="sub">{ident} · {html.escape(section['title'])}</div>
            <div class="terminal">{''.join(lines)}</div>
            <div class="foot">Нақты орындалу журналының көрінісі · results/{log} · Табидулла Абылайхан, АЖ45</div></html>'''
            target = ROOT / "screenshots" / ident
            target.with_suffix(".html").write_text(body, encoding="utf-8")
            page.set_content(body, wait_until="load")
            page.locator("body").screenshot(path=str(target.with_suffix(".png")))
            print(ident, page.locator("body").bounding_box()["height"])
        browser.close()


if __name__ == "__main__":
    main()
