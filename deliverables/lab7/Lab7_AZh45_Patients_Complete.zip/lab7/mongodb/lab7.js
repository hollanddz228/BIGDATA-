// mongosh --quiet /tmp/lab7.js
// Қайта орындау тек осы зертханаға тиесілі hospital_lab7.patients деректерін қалпына келтіреді.
const fs = require('fs');
const outDir = '/tmp/lab7-results';
fs.mkdirSync(outDir, {recursive: true});
function section(id, title) { print('\n=== ' + id + ' | ' + title + ' ==='); }
function command(code, action) {
  print('hospital_lab7> ' + code);
  const result = action();
  if (result !== undefined) print(EJSON.stringify(result, null, 0, {relaxed: true}));
  return result;
}
function save(name, data) { fs.writeFileSync(outDir + '/' + name, JSON.stringify(data, null, 2)); }
const summary = {};
function assertEq(expected, actual) {
  if (EJSON.stringify(expected) !== EJSON.stringify(actual)) {
    throw new Error('Тексеру қатесі: expected=' + expected + ', actual=' + actual);
  }
}
section('M01', 'Деректер базасы, схема және бірегей индекс');
db = db.getSiblingDB('hospital_lab7');
print('mongosh> use hospital_lab7');
print('switched to db hospital_lab7');
// Тек осы зертхананың коллекциясын қайта құру: схема әр іске қосуда тексеріледі.
command('db.patients.drop() // тек hospital_lab7 оқу коллекциясы', () => db.patients.drop());
{
  command('db.createCollection("patients", {validator: {$jsonSchema: {bsonType: "object", required: ["id","name","age","diagnosis","room"], properties: {id: {bsonType: "int", minimum: 1}, name: {bsonType: "string"}, age: {bsonType: "int", minimum: 21, maximum: 120}, diagnosis: {bsonType: "string"}, room: {bsonType: "int", minimum: 101}}}}})', () => db.createCollection('patients', {validator: {$jsonSchema: {bsonType: 'object', required: ['id','name','age','diagnosis','room'], properties: {id: {bsonType: 'int', minimum: 1}, name: {bsonType: 'string'}, age: {bsonType: 'int', minimum: 21, maximum: 120}, diagnosis: {bsonType: 'string'}, room: {bsonType: 'int', minimum: 101}}}}}));
}
command('db.patients.createIndex({id: 1}, {unique: true})', () => db.patients.createIndex({id:1}, {unique:true}));
// Оқу деректерін бастапқы күйге келтіру. Басқа деректер базаларына тимейді.
section('M02', '768 пациентті енгізу');
const patients = JSON.parse(fs.readFileSync('/tmp/patients.json', 'utf8')).map(p => ({...p, id:NumberInt(p.id), age:NumberInt(p.age), room:NumberInt(p.room)}));
command('const patients = JSON.parse(fs.readFileSync("/tmp/patients.json", "utf8")).map(p => ({...p, id:NumberInt(p.id), age:NumberInt(p.age), room:NumberInt(p.room)})); db.patients.insertMany(patients)', () => {
  const result = db.patients.insertMany(patients);
  return {acknowledged:result.acknowledged, insertedCount:Object.keys(result.insertedIds).length};
});
summary.initial_count = command('db.patients.countDocuments({})', () => db.patients.countDocuments({}));
assertEq(768, summary.initial_count);
section('M03', 'Барлық 768 жазбаны шығару');
print('hospital_lab7> db.patients.find({}, {_id:0}).sort({id:1}).forEach(p => print(EJSON.stringify(p)))');
const all = db.patients.find({}, {_id:0}).sort({id:1}).toArray();
all.forEach(p => print(EJSON.stringify(p)));
save('mongo_all_before.json', all);
summary.all_read_count = all.length;
section('M04', 'Бірегей ID бойынша іздеу');
summary.id3 = command('db.patients.findOne({id:3}, {_id:0})', () => db.patients.findOne({id:3}, {_id:0}));
section('M05', 'Сандық room өрісін өзгерту');
summary.before_update = command('db.patients.findOne({id:2}, {_id:0})', () => db.patients.findOne({id:2}, {_id:0}));
command('db.patients.updateOne({id:2}, {$set:{room:NumberInt(215)}})', () => db.patients.updateOne({id:2}, {$set:{room:NumberInt(215)}}));
summary.after_update = command('db.patients.findOne({id:2}, {_id:0})', () => db.patients.findOne({id:2}, {_id:0}));
assertEq(102, summary.before_update.room); assertEq(215, summary.after_update.room);
section('M06', 'Бір жазбаны жою');
command('db.patients.findOne({id:768}, {_id:0})', () => db.patients.findOne({id:768}, {_id:0}));
command('db.patients.deleteOne({id:768})', () => db.patients.deleteOne({id:768}));
summary.deleted_record = command('db.patients.findOne({id:768})', () => db.patients.findOne({id:768}));
assertEq(null, summary.deleted_record);
section('M07', 'Жалпы санын есептеу');
summary.final_count = command('db.patients.countDocuments({})', () => db.patients.countDocuments({}));
assertEq(767, summary.final_count);
section('M08', 'Жас бойынша салыстыру шарты');
summary.over40_count = command('db.patients.countDocuments({age:{$gt:40}})', () => db.patients.countDocuments({age:{$gt:40}}));
const filtered = db.patients.find({age:{$gt:40}}, {_id:0}).sort({id:1}).toArray();
command('db.patients.find({age:{$gt:40}}, {_id:0}).sort({id:1}).limit(5).toArray()', () => filtered.slice(0,5));
save('mongo_age_gt40.json', filtered);
section('M09', 'Барлық жазбаны жас бойынша сұрыптау');
const sorted = db.patients.find({}, {_id:0}).sort({age:-1,id:1}).toArray();
command('db.patients.find({}, {_id:0}).sort({age:-1,id:1}).limit(5).toArray()', () => sorted.slice(0,5));
save('mongo_sorted_age_desc.json', sorted);
summary.sorted_top5 = sorted.slice(0,5);
section('M10', 'Қосымша: age > 40 және кему реті');
const combined = db.patients.find({age:{$gt:40}}, {_id:0}).sort({age:-1,id:1}).toArray();
command('db.patients.find({age:{$gt:40}}, {_id:0}).sort({age:-1,id:1}).limit(5).toArray()', () => combined.slice(0,5));
print('Толық нәтиже саны: ' + combined.length);
save('mongo_filtered_sorted.json', combined);
section('M11', 'Қорытынды күй және тексерулер');
const finalRows = db.patients.find({}, {_id:0}).sort({id:1}).toArray();
save('mongo_final.json', finalRows);
summary.version = db.version();
summary.unique_id_count = db.patients.distinct('id').length;
assertEq(summary.final_count, summary.unique_id_count);
summary.status = 'PASS';
print(EJSON.stringify(summary, null, 2));
save('mongo_summary.json', summary);
print('ALL_MONGODB_CHECKS_PASS');
