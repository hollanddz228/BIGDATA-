#!/usr/bin/env python3
"""Пайдаланушының түпнұсқа скриншоттарынан Word есебін жинау."""
import argparse
import json
import unicodedata
from pathlib import Path
from datetime import datetime, timezone

from docx import Document
from docx.enum.section import WD_SECTION_START, WD_ORIENT
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_TAB_ALIGNMENT, WD_TAB_LEADER
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor
from PIL import Image

from report_spec import PAGES, IMAGES

ROOT = Path(__file__).resolve().parent

def normalized(name):
    return unicodedata.normalize('NFC',name).casefold().strip()

def resolve_images(folder):
    found = {}
    for file in folder.rglob('*'):
        if file.is_file() and file.suffix.lower() in ('.png','.jpg','.jpeg'):
            found.setdefault(normalized(file.name),[]).append(file)
    resolved, missing = {}, {}
    for key, names in IMAGES.items():
        matches=[]
        for name in names:
            matches += found.get(normalized(name),[])
        if matches:
            resolved[key]=matches[0]
        else:
            missing[key]=names
    return resolved,missing

def configure_section(section,landscape=False,first=False):
    section.orientation=WD_ORIENT.LANDSCAPE if landscape else WD_ORIENT.PORTRAIT
    section.page_width=Cm(29.7 if landscape else 21)
    section.page_height=Cm(21 if landscape else 29.7)
    section.left_margin=section.right_margin=Cm(1.8)
    section.top_margin=section.bottom_margin=Cm(1.5)
    section.header_distance=section.footer_distance=Cm(0.65)
    section.different_first_page_header_footer=first

def build(image_dir,target,text_only=False,toc_map=None):
    images,missing=resolve_images(image_dir)
    if missing and not text_only:
        raise SystemExit('Original screenshots are required:\n'+json.dumps(missing,ensure_ascii=False,indent=2))
    doc=Document()
    configure_section(doc.sections[0],first=True)
    styles=doc.styles
    for key in ('Normal','Title','Heading 1','Heading 2','Caption'):
        styles[key].font.name='Times New Roman'
    styles['Normal'].font.size=Pt(12)
    styles['Normal'].paragraph_format.line_spacing=1.1
    styles['Normal'].paragraph_format.space_after=Pt(6)
    styles['Normal'].paragraph_format.widow_control=True
    for key,size in (('Title',23),('Heading 1',16),('Heading 2',13)):
        styles[key].font.size=Pt(size)
        styles[key].font.color.rgb=RGBColor.from_string('173C55')
        styles[key].paragraph_format.space_before=Pt(0)
        styles[key].paragraph_format.space_after=Pt(7)
    styles['Caption'].font.size=Pt(10)
    styles['Caption'].font.color.rgb=RGBColor.from_string('425C6B')
    styles['Caption'].paragraph_format.space_after=Pt(6)
    for style in styles:
        if style.type==1:
            lang=OxmlElement('w:lang');lang.set(qn('w:val'),'kk-KZ')
            style.element.get_or_add_rPr().append(lang)
    header=doc.sections[0].header.paragraphs[0]
    header.text='BIG DATA  •  №7 зертханалық жұмыс  •  Аурухана  •  АЖ45'
    header.runs[0].font.size=Pt(9)
    header.runs[0].font.color.rgb=RGBColor.from_string('556C7D')
    footer=doc.sections[0].footer.paragraphs[0]
    footer.alignment=WD_ALIGN_PARAGRAPH.RIGHT
    footer.add_run('Табидулла Абылайхан  |  ').font.size=Pt(9)
    number=OxmlElement('w:fldSimple');number.set(qn('w:instr'),'PAGE');footer._p.append(number)
    doc.core_properties.title='Зертханалық жұмыс №7: MongoDB және Cassandra. №7 нұсқа — Аурухана'
    doc.core_properties.subject='Windows, Docker Desktop, MongoDB Compass, cqlsh; 768 жазба'
    doc.core_properties.author='Табидулла Абылайхан'
    doc.core_properties.keywords='АЖ45, BigDATA, patients, MongoDB, Cassandra'
    doc.core_properties.created=datetime.now(timezone.utc)
    doc.core_properties.modified=datetime.now(timezone.utc)

    def p(text='',size=None,center=False,bold=False):
        paragraph=doc.add_paragraph()
        paragraph.alignment=WD_ALIGN_PARAGRAPH.CENTER if center else WD_ALIGN_PARAGRAPH.JUSTIFY
        run=paragraph.add_run(text);run.bold=bold
        if size:run.font.size=Pt(size)
        return paragraph

    p();p()
    p('ҮЛКЕН ДЕРЕКТЕРДІ ӨҢДЕУ\n(BigDATA)',16,True,True)
    p()
    title=doc.add_paragraph('ЗЕРТХАНАЛЫҚ ЖҰМЫС №7',style='Title')
    title.alignment=WD_ALIGN_PARAGRAPH.CENTER
    p('NoSQL деректер базалары:\nMongoDB және Cassandra',18,True)
    p()
    p('№7 нұсқа — Аурухана\npatients: id, name, age, diagnosis, room',14,True)
    p();p()
    p('Орындаған: Табидулла Абылайхан',14,bold=True)
    p('Тобы: АЖ45',14,bold=True)
    p('Орындалған күні: 16.10.2026',12)
    p()
    p('Бастапқы деректер: 768 жазба\nҚорытындысы: әр базада 767 жазба',12,True)
    if text_only:p('МӘТІНДІК ЖОБА — түпнұсқа суреттер енгізілмеген',12,True,True)
    p();p('2026 жыл',12,True)

    section=doc.add_section(WD_SECTION_START.NEW_PAGE)
    configure_section(section)
    doc.add_heading('МАЗМҰНЫ',level=1)
    for index,content_page in enumerate(PAGES,1):
        para=doc.add_paragraph()
        para.paragraph_format.space_after=Pt(4)
        para.paragraph_format.line_spacing=1
        para.paragraph_format.tab_stops.add_tab_stop(Cm(17.1),WD_TAB_ALIGNMENT.RIGHT,WD_TAB_LEADER.DOTS)
        hyperlink=OxmlElement('w:hyperlink');hyperlink.set(qn('w:anchor'),f'section_{index}')
        run=OxmlElement('w:r');props=OxmlElement('w:rPr')
        font=OxmlElement('w:rFonts');font.set(qn('w:ascii'),'Times New Roman');font.set(qn('w:hAnsi'),'Times New Roman');props.append(font)
        size=OxmlElement('w:sz');size.set(qn('w:val'),'22');props.append(size)
        run.append(props);label=OxmlElement('w:t');label.text=content_page['title'];run.append(label)
        hyperlink.append(run);para._p.append(hyperlink)
        page_num=(toc_map or {}).get(content_page['title'],'—')
        para.add_run('\t'+str(page_num)).font.size=Pt(11)

    figure_number=0
    for section_index,content_page in enumerate(PAGES,1):
        section=doc.add_section(WD_SECTION_START.NEW_PAGE)
        configure_section(section,content_page['landscape'])
        heading=doc.add_heading(content_page['title'],level=1)
        mark=OxmlElement('w:bookmarkStart');mark.set(qn('w:id'),str(section_index));mark.set(qn('w:name'),f'section_{section_index}')
        end=OxmlElement('w:bookmarkEnd');end.set(qn('w:id'),str(section_index))
        heading._p.insert(0,mark);heading._p.append(end)
        for item in content_page['items']:
            kind=item['kind']
            if kind=='paragraph':
                text=item['text']
                p(text,9 if text.startswith('https://raw.') else None)
            elif kind=='code':
                para=p(item['text'])
                para.alignment=WD_ALIGN_PARAGRAPH.LEFT
                para.paragraph_format.line_spacing=1
                para.paragraph_format.space_after=Pt(8)
                for run in para.runs:
                    run.font.name='DejaVu Sans Mono';run.font.size=Pt(9)
                shade=OxmlElement('w:shd');shade.set(qn('w:fill'),'F0F4F6')
                para._p.get_or_add_pPr().append(shade)
            elif kind=='table':
                tab=doc.add_table(rows=1,cols=len(item['headers']))
                tab.style='Table Grid';tab.autofit=False
                widths=item['widths']
                if widths:
                    for column,width in zip(tab.columns,widths):column.width=Cm(width)
                for i,label in enumerate(item['headers']):tab.rows[0].cells[i].text=str(label)
                for row in item['rows']:
                    for cell,value in zip(tab.add_row().cells,row):cell.text=str(value)
                for row_index,row in enumerate(tab.rows):
                    no_split=OxmlElement('w:cantSplit');row._tr.get_or_add_trPr().append(no_split)
                    if row_index==0:row._tr.get_or_add_trPr().append(OxmlElement('w:tblHeader'))
                    for i,cell in enumerate(row.cells):
                        if widths:cell.width=Cm(widths[i])
                        if row_index==0:
                            shade=OxmlElement('w:shd');shade.set(qn('w:fill'),'E6EEF3')
                            cell._tc.get_or_add_tcPr().append(shade)
                        for para in cell.paragraphs:
                            para.paragraph_format.space_after=Pt(3)
                            para.paragraph_format.space_before=Pt(3)
                            para.paragraph_format.line_spacing=1
                            for run in para.runs:
                                run.font.size=Pt(10.5);run.bold=row_index==0
                p()
            elif kind=='figure':
                figure_number+=1
                if text_only:
                    p(f'[Түпнұсқа сурет орны: {item["key"]}]',10)
                else:
                    image_file=images[item['key']]
                    with Image.open(image_file) as im:w,h=im.size
                    max_width=26.1 if content_page['landscape'] else 17.4
                    width_cm=min(max_width,item['max_height']*w/h)
                    para=doc.add_paragraph();para.alignment=WD_ALIGN_PARAGRAPH.CENTER
                    para.paragraph_format.space_after=Pt(3)
                    para.paragraph_format.keep_with_next=True
                    picture=para.add_run().add_picture(str(image_file),width=Cm(width_cm))
                    picture._inline.docPr.set('descr',item['caption'])
                caption=doc.add_paragraph(f'{figure_number}-сурет. {item["caption"]}.',style='Caption')
                caption.alignment=WD_ALIGN_PARAGRAPH.CENTER
    target.parent.mkdir(exist_ok=True,parents=True)
    doc.save(target)
    print(target)
    print('Figures:',figure_number,'; original images available:',len(images))

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--images',type=Path,default=ROOT/'original_screenshots')
    parser.add_argument('--output',type=Path,default=ROOT/'Lab7_Tabidulla_AZh45_Final.docx')
    parser.add_argument('--text-only',action='store_true')
    parser.add_argument('--toc-map',type=Path)
    args=parser.parse_args()
    if args.text_only and args.output.name=='Lab7_Tabidulla_AZh45_Final.docx':
        args.output=ROOT/'draft_text_only.docx'
    toc_map=json.loads(args.toc_map.read_text(encoding='utf-8')) if args.toc_map else None
    build(args.images,args.output,args.text_only,toc_map)
